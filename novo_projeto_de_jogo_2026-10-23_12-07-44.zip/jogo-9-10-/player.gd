
extends CharacterBody2D


# CONFIGURAÇÕES

@export var speed: float = 200.0
@export var gravity: float = 900.0
@export var jump_velocity: float = -400.0


# VIDA

@export var max_health: int = 100
var health: int
var is_dead: bool = false

@onready var health_bar: ProgressBar = $"../HUD/HealthBar"
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var som_passo: AudioStreamPlayer = $SomPasso


# ATAQUE PULANDO

@export var stomp_damage: int = 10
@export var bounce_velocity: float = -300.0


# MENU DE PAUSE

var pause_menu: CanvasLayer = null


func _ready() -> void:
	health = max_health

	health_bar.max_value = max_health
	health_bar.value = health

	# Procura o menu na cena atual
	pause_menu = get_tree().current_scene.find_child(
		"PauseMenu",
		true,
		false
	) as CanvasLayer

	if pause_menu == null:
		print("ERRO: não encontrei um Control chamado PauseMenu!")
	else:
		print("PauseMenu encontrado: ", pause_menu.get_path())


# TECLA TAB

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_TAB:
			print("TAB pressionado!")

			if is_dead:
				return

			if pause_menu == null or not is_instance_valid(pause_menu):
				print("ERRO: o menu de pause não foi encontrado.")
				return

			if get_tree().paused:
				pause_menu.continuar_jogo()
			else:
				pause_menu.abrir_pause()


# FÍSICA

func _physics_process(delta: float) -> void:
	if is_dead:
		return

	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		velocity.y = 0

	var direction := Input.get_axis("esquerda", "direita")

	if direction != 0:
		velocity.x = direction * speed
		animated_sprite.flip_h = direction < 0
	else:
		velocity.x = move_toward(velocity.x, 0, speed)

	if Input.is_action_just_pressed("pular") and is_on_floor():
		velocity.y = jump_velocity

	if is_on_floor():
		if direction != 0:
			animated_sprite.play("run")

			if not som_passo.playing:
				som_passo.play()
		else:
			animated_sprite.play("idle")
			som_passo.stop()
	else:
		som_passo.stop()

	move_and_slide()

	check_enemy_stomp()


# PISAR NO INIMIGO

func check_enemy_stomp() -> void:
	if velocity.y <= 0:
		return

	for i in get_slide_collision_count():
		var collision := get_slide_collision(i)
		var body := collision.get_collider()

		if body and body.is_in_group("enemy"):
			if body.has_method("take_damage"):
				body.take_damage(stomp_damage)
				velocity.y = bounce_velocity
				print("Player pisou no inimigo!")


# RECEBER DANO

func take_damage(damage: int) -> void:
	if is_dead:
		return

	health -= damage
	health = max(health, 0)
	health_bar.value = health

	print("Player tomou ", damage, " de dano. Vida: ", health)

	if health <= 0:
		die()


# MORTE

func die() -> void:
	if is_dead:
		return

	is_dead = true
	velocity = Vector2.ZERO
	som_passo.stop()
	set_physics_process(false)

	animated_sprite.play("death")

	await get_tree().create_timer(1.0).timeout

	get_tree().change_scene_to_file("res://game_over.tscn")
