
extends CanvasLayer

@onready var botao_continuar: Button = $Button
@onready var botao_menu: Button = $Button2


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	hide()

	botao_continuar.pressed.connect(continuar_jogo)
	botao_menu.pressed.connect(voltar_menu)


func abrir_pause() -> void:
	show()
	get_tree().paused = true


func continuar_jogo() -> void:
	get_tree().paused = false
	hide()


func voltar_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://menu.tscn")
