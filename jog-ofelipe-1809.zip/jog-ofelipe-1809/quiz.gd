extends Control


func _ready():
	# BOTÃO 1 - Albânia = ERRADO
	$Button.pressed.connect(resposta_errada)

	# BOTÃO 2 - Bósnia = CERTO
	$Button2.pressed.connect(resposta_certa)

	# BOTÃO 3 - Colômbia = ERRADO
	$Button3.pressed.connect(resposta_errada)

	# BOTÃO 4 - Moldávia = ERRADO
	$Button4.pressed.connect(resposta_errada)


# =========================
# RESPOSTA CORRETA
# =========================
func resposta_certa():
	get_tree().change_scene_to_file("res://level_2.tscn")


# =========================
# RESPOSTA ERRADA
# =========================
func resposta_errada():
	get_tree().change_scene_to_file("res://level_1.tscn")
