extends CharacterBody2D


# =========================
# CONFIGURAÇÕES
# =========================

@export var speed: float = 100.0
@export var gravity: float = 400.0
@export var jump_velocity: float = -150.0

@export var player: CharacterBody2D


# =========================
# VIDA
# =========================

@export var max_health: int = 30
var health: int = 30
var is_dead: bool = false


# =========================
# VISÃO
# =========================

@export var vision_range: float = 500.0


# =========================
# ATAQUE
# =========================

@export var attack_damage: int = 10
@export var attack_range: float = 50.0
@export var attack_cooldown: float = 1.0

var can_attack: bool = true
var is_attacking: bool = false


# =========================
# ANIMAÇÃO
# =========================

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


# =========================
# INICIALIZAÇÃO
# =========================

func _ready() -> void:

	health = max_health

	add_to_group("enemy")


# =========================
# FÍSICA
# =========================

func _physics_process(delta: float) -> void:

	if is_dead:
		return


	# GRAVIDADE

	if not is_on_floor():

		velocity.y += gravity * delta

	else:

		velocity.y = 0


	# SEM PLAYER

	if player == null:

		velocity.x = 0

		animated_sprite.play("idle")

		move_and_slide()

		return


	# DISTÂNCIA

	var distance_x: float = abs(
		player.global_position.x - global_position.x
	)


	# PLAYER FORA DA VISÃO

	if distance_x > vision_range:

		velocity.x = 0

		animated_sprite.play("idle")

		move_and_slide()

		return


	# PLAYER PERTO

	if distance_x <= attack_range:

		velocity.x = 0

		attack()

		move_and_slide()

		return


	# =========================
	# PERSEGUIR PLAYER
	# =========================

	var direction: float = sign(
		player.global_position.x - global_position.x
	)

	velocity.x = direction * speed


	# VIRAR SPRITE

	if direction > 0:

		animated_sprite.flip_h = false

	else:

		animated_sprite.flip_h = true


	# =========================
	# PULO
	# =========================

	if is_on_floor():

		if player.global_position.y < global_position.y - 40:

			velocity.y = jump_velocity


	# =========================
	# ANIMAÇÃO
	# =========================

	animated_sprite.play("run")


	# =========================
	# MOVIMENTO
	# =========================

	move_and_slide()


# =========================
# ATAQUE
# =========================

func attack() -> void:

	if not can_attack:
		return

	if is_dead:
		return

	can_attack = false
	is_attacking = true

	velocity.x = 0

	animated_sprite.play("attack")


	# DANO NO PLAYER

	if player != null:

		if player.has_method("take_damage"):

			player.take_damage(attack_damage)


	# ESPERA A ANIMAÇÃO

	await animated_sprite.animation_finished


	if is_dead:
		return


	is_attacking = false


	# COOLDOWN

	await get_tree().create_timer(
		attack_cooldown
	).timeout


	if is_dead:
		return


	can_attack = true


# =========================
# RECEBER DANO
# =========================

func take_damage(damage: int) -> void:

	if is_dead:
		return


	health -= damage

	health = max(health, 0)


	print(
		"Enemy tomou ",
		damage,
		" de dano. Vida: ",
		health
	)


	# MORTE

	if health <= 0:

		die()


# =========================
# MORTE
# =========================

func die() -> void:

	if is_dead:
		return


	is_dead = true

	is_attacking = false

	velocity = Vector2.ZERO

	animated_sprite.play("death")


	# Espera a animação

	await animated_sprite.animation_finished


	# Remove o Enemy

	queue_free()
