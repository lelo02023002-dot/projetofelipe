extends CharacterBody2D

# =========================
# CONFIGURAÇÕES
# =========================

@export var speed: float = 200.0
@export var gravity: float = 900.0
@export var jump_velocity: float = -400.0


# =========================
# VIDA
# =========================

@export var max_health: int = 100
var health: int
var is_dead: bool = false

@onready var health_bar: ProgressBar = $"../HUD/HealthBar"
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


# =========================
# ATAQUE PULANDO
# =========================

@export var stomp_damage: int = 10
@export var bounce_velocity: float = -300.0


# =========================
# INICIALIZAÇÃO
# =========================

func _ready() -> void:

	health = max_health

	health_bar.max_value = max_health
	health_bar.value = health


# =========================
# FÍSICA
# =========================

func _physics_process(delta: float) -> void:

	if is_dead:
		return


	# =========================
	# GRAVIDADE
	# =========================

	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		velocity.y = 0


	# =========================
	# MOVIMENTO
	# =========================

	var direction := Input.get_axis("esquerda", "direita")

	if direction != 0:

		velocity.x = direction * speed

		if direction > 0:
			animated_sprite.flip_h = false
		else:
			animated_sprite.flip_h = true

	else:

		velocity.x = move_toward(
			velocity.x,
			0,
			speed
		)


	# =========================
	# PULO
	# =========================

	if Input.is_action_just_pressed("pular") and is_on_floor():

		velocity.y = jump_velocity


	# =========================
	# ANIMAÇÕES
	# =========================

	if not is_on_floor():

		animated_sprite.play("jump")

	elif direction != 0:

		animated_sprite.play("run")

	else:

		animated_sprite.play("idle")


	# =========================
	# MOVIMENTO
	# =========================

	move_and_slide()


	# =========================
	# VERIFICA INIMIGOS
	# =========================

	check_enemy_stomp()


# =========================
# PISAR NO INIMIGO
# =========================

func check_enemy_stomp() -> void:

	# Só pode atacar pulando para baixo
	if velocity.y <= 0:
		return


	for i in get_slide_collision_count():

		var collision := get_slide_collision(i)

		var body := collision.get_collider()

		if body and body.is_in_group("enemy"):

			if body.has_method("take_damage"):

				body.take_damage(stomp_damage)

				# Player pula novamente
				velocity.y = bounce_velocity

				print("Player pisou no inimigo!")


# =========================
# RECEBER DANO
# =========================

func take_damage(damage: int) -> void:

	if is_dead:
		return

	health -= damage
	health = max(health, 0)

	health_bar.value = health

	print(
		"Player tomou ",
		damage,
		" de dano. Vida: ",
		health
	)

	if health <= 0:

		die()


# =========================
# MORTE
# =========================

func die() -> void:

	if is_dead:
		return

	is_dead = true

	velocity = Vector2.ZERO

	set_physics_process(false)

	animated_sprite.play("death")

	await get_tree().create_timer(1.0).timeout

	get_tree().reload_current_scene()
