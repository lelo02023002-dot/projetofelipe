extends Control


func _ready():
	# BOTÃO 1 - Austrália = CORRETO
	$Button.pressed.connect(resposta_certa)

	# BOTÃO 2 - Nova Zelândia = ERRADO
	$Button2.pressed.connect(resposta_errada)

	# BOTÃO 3 - Inglaterra = ERRADO
	$Button3.pressed.connect(resposta_errada)

	# BOTÃO 4 - Costa Rica = ERRADO
	$Button4.pressed.connect(resposta_errada)


# =========================
# RESPOSTA CORRETA
# =========================
func resposta_certa():
	get_tree().change_scene_to_file("res://level_3.tscn")


# =========================
# RESPOSTA ERRADA
# =========================
func resposta_errada():
	get_tree().change_scene_to_file("res://level_2.tscn")
