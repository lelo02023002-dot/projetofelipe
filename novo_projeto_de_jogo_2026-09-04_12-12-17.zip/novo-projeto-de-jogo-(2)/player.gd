extends CharacterBody2D


# =========================
# CONFIGURAÇÕES
# =========================

@export var speed: float = 100.0
@export var gravity: float = 900.0
@export var jump_velocity: float = -400.0

@export var player: CharacterBody2D


# =========================
# VIDA
# =========================

@export var max_health: int = 30

var health: int


# =========================
# VISÃO
# =========================

@export var vision_range: float = 500.0


# =========================
# ATAQUE
# =========================

@export var attack_damage: int = 10
@export var attack_range: float = 50.0
@export var attack_cooldown: float = 1.0

var can_attack: bool = true
var is_attacking: bool = false


# =========================
# ANIMAÇÃO
# =========================

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


# =========================
# RAYCAST
# =========================

@onready var ray_cast: RayCast2D = $RayCast2D


# =========================
# INICIALIZAÇÃO
# =========================

func _ready() -> void:

	health = max_health


# =========================
# FÍSICA
# =========================

func _physics_process(delta: float) -> void:

	# -------------------------
	# GRAVIDADE
	# -------------------------

	if not is_on_floor():

		velocity.y += gravity * delta

	else:

		velocity.y = 0


	# -------------------------
	# ATAQUE
	# -------------------------

	if is_attacking:

		velocity.x = 0

		move_and_slide()

		return


	# -------------------------
	# PLAYER
	# -------------------------

	if player:

		var distance_x = abs(
			player.global_position.x -
			global_position.x
		)


		# =========================
		# PLAYER FOI VISTO
		# =========================

		if distance_x <= vision_range:


			# =========================
			# PLAYER LONGE
			# =========================

			if distance_x > attack_range:

				# Vai para a direita
				if player.global_position.x > global_position.x:

					velocity.x = speed

					animated_sprite.flip_h = false

					ray_cast.target_position.x = 35


				# Vai para a esquerda
				else:

					velocity.x = -speed

					animated_sprite.flip_h = true

					ray_cast.target_position.x = -35


				# =========================
				# PULO
				# =========================

				if is_on_floor() and ray_cast.is_colliding():

					velocity.y = jump_velocity


				# =========================
				# PLAYER ACIMA
				# =========================

				elif is_on_floor():

					if player.global_position.y < global_position.y - 25:

						velocity.y = jump_velocity


				# =========================
				# CORRER
				# =========================

				animated_sprite.play("run")


			# =========================
			# PLAYER PERTO
			# =========================

			else:

				velocity.x = 0

				attack()


		# =========================
		# PLAYER NÃO FOI VISTO
		# =========================

		else:

			velocity.x = 0

			animated_sprite.play("idle")


	# =========================
	# SEM PLAYER
	# =========================

	else:

		velocity.x = 0

		animated_sprite.play("idle")


	# -------------------------
	# MOVIMENTO
	# -------------------------

	move_and_slide()


# =========================
# ATAQUE DO INIMIGO
# =========================

func attack() -> void:

	if not can_attack:

		return


	can_attack = false

	is_attacking = true

	velocity.x = 0

	animated_sprite.play("attack")


	# Causa dano no Player

	if player and player.has_method("take_damage"):

		player.take_damage(attack_damage)


	# Espera a animação terminar

	await animated_sprite.animation_finished

	is_attacking = false


	# Tempo entre ataques

	await get_tree().create_timer(
		attack_cooldown
	).timeout

	can_attack = true


# =========================
# RECEBER DANO
# =========================

func take_damage(damage: int) -> void:

	health -= damage

	health = max(health, 0)


	print(
		"Inimigo tomou ",
		damage,
		" de dano. Vida: ",
		health
	)


	# Morreu?

	if health <= 0:

		die()


# =========================
# MORTE
# =========================

func die() -> void:

	is_attacking = true

	velocity = Vector2.ZERO

	animated_sprite.play("death")


	# Espera a animação de morte

	await animated_sprite.animation_finished

	queue_free()
