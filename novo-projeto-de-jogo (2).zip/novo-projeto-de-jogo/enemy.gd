extends CharacterBody2D

@export var speed := 100.0
@export var player: CharacterBody2D

func _physics_process(_delta):
	if player:
		var direction = global_position.direction_to(player.global_position)
		velocity = direction * speed
		move_and_slide()
