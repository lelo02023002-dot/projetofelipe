extends CharacterBody2D


# --- Configurações ---
@export var speed: float = 100.0

# Referência ao Player
@export var player: CharacterBody2D

# --- Dano ---
@export var damage: int = 20
@export var attack_cooldown: float = 1.0

var can_attack: bool = true


func _physics_process(_delta):
	if player:
		
		# Faz o inimigo seguir o jogador
		var direction = global_position.direction_to(player.global_position)

		velocity = direction * speed

		move_and_slide()


		# Verifica se chegou perto do jogador
		if global_position.distance_to(player.global_position) < 50:
			attack_player()


# --- Ataque ---
func attack_player() -> void:

	if not can_attack:
		return

	can_attack = false

	# Causa dano ao jogador
	player.take_damage(damage)

	print("Inimigo atacou! Dano: ", damage)

	# Espera antes de poder atacar novamente
	await get_tree().create_timer(attack_cooldown).timeout

	can_attack = true
			
