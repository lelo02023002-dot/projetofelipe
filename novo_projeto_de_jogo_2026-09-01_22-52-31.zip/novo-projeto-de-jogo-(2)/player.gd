extends CharacterBody2D


# --- Configurações ---
@export var speed: float = 200.0
@export var jump_velocity: float = -400.0
@export var gravity: float = 900.0

# --- Vida ---
@export var max_health: int = 100
var health: int


# --- Referência ao AnimatedSprite2D ---
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


enum State { IDLE, RUN, JUMP }
var current_state: State = State.IDLE


func _ready() -> void:
	health = max_health


func _physics_process(delta):
	# Aplica gravidade
	if not is_on_floor():
		velocity.y += gravity * delta

	# Pulo
	if Input.is_action_just_pressed("pular") and is_on_floor():
		velocity.y = jump_velocity

	# Movimento horizontal
	var direction: float = Input.get_axis("esquerda", "direita")

	if direction != 0:
		velocity.x = direction * speed
		animated_sprite.flip_h = direction < 0
	else:
		velocity.x = move_toward(velocity.x, 0, speed)

	move_and_slide()

	update_state()
	update_animation()


# --- Receber dano ---
func take_damage(damage: int) -> void:
	health -= damage

	print("Vida do jogador: ", health)

	if health <= 0:
		die()


# --- Morte ---
func die() -> void:
	print("Jogador morreu!")
	get_tree().reload_current_scene()


# --- Estado ---
func update_state() -> void:
	if not is_on_floor():
		current_state = State.JUMP
	elif abs(velocity.x) > 10:
		current_state = State.RUN
	else:
		current_state = State.IDLE


# --- Animação ---
func update_animation() -> void:
	match current_state:
		State.IDLE:
			animated_sprite.play("idle")

		State.RUN:
			animated_sprite.play("run")

		State.JUMP:
			animated_sprite.play("jump")
			
