
extends Area2D

var coletada: bool = false

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if coletada or body.name != "Player":
		return

	var mao := body.get_node_or_null("Mao") as Marker2D
	if mao == null:
		push_error("Mao nao encontrada no Player.")
		return

	coletada = true
	print("ARMA COLETADA")

	set_deferred("monitoring", false)
	set_deferred("monitorable", false)

	var colisao := get_node_or_null("CollisionShape2D")
	if colisao is CollisionShape2D:
		colisao.set_deferred("disabled", true)

	var sprite := get_node_or_null("Sprite2D") as Sprite2D

	reparent(body, false)
	position = mao.position + Vector2(8, -4)
	rotation = 0.0
	z_index = 100
	z_as_relative = false
	show()

	if sprite != null:
		sprite.show()
		sprite.z_index = 100
		sprite.z_as_relative = false
