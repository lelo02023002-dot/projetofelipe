
extends CanvasLayer

@onready var fundo: ColorRect = $Fundo
@onready var botao_retomar: Button = $CenterContainer/VBoxContainer/BotaoRetomar
@onready var botao_menu: Button = $CenterContainer/VBoxContainer/BotaoMenu


func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS

	visible = false

	botao_retomar.pressed.connect(retomar_jogo)
	botao_menu.pressed.connect(voltar_menu)

	print("MENU DE PAUSE CARREGADO!")


func _input(event):
	if event.is_action_pressed("ui_cancel") and not event.is_echo():

		if visible:
			retomar_jogo()
		else:
			abrir_pause()

		get_viewport().set_input_as_handled()


func abrir_pause():
	visible = true
	get_tree().paused = true
	print("JOGO PAUSADO!")


func retomar_jogo():
	get_tree().paused = false
	visible = false
	print("JOGO RETOMADO!")


func voltar_menu():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://menu.tscn")


func _on_botao_retomar_pressed() -> void:
	pass # Replace with function body.


func _on_botao_menu_pressed() -> void:
	pass # Replace with function body.
