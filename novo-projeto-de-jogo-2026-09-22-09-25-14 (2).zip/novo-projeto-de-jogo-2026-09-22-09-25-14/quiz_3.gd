extends Control

func _ready():
	# BOTÃO 1 - Azerbaijão = ERRADO
	$Button.pressed.connect(resposta_errada)

	# BOTÃO 2 - Canadá = ERRADO
	$Button2.pressed.connect(resposta_errada)

	# BOTÃO 3 - Áustria = CERTO
	$Button3.pressed.connect(resposta_certa)

	# BOTÃO 4 - Noruega = ERRADO
	$Button4.pressed.connect(resposta_errada)


# =========================
# RESPOSTA CORRETA
# =========================
func resposta_certa():
	get_tree().change_scene_to_file("res://level_5.tscn")


# =========================
# RESPOSTA ERRADA
# =========================
func resposta_errada():
	get_tree().change_scene_to_file("res://level_4.tscn")
