extends CharacterBody2D

var health = 10 # O boss aguenta 10 pulos na cabeça
const SPEED = 60.0
var gravity = 980.0

# @export permite arrastar o Node do Player lá no Inspector da Fase!
@export var player_node: Node2D
@onready var health_bar = $HealthBar

func _ready():
	health_bar.max_value = health
	health_bar.value = health

func _physics_process(delta):
	if not is_on_floor(): velocity.y += gravity * delta
	
	# Se o player existir na fase, vai na direção dele!
	if player_node:
		var direction = sign(player_node.global_position.x - global_position.x)
		velocity.x = direction * SPEED
		$AnimatedSprite2D.flip_h = (direction < 0)
		
	move_and_slide()

# Função chamada quando o Player pisa no HeadBox!
func take_damage(amount):
	health -= amount
	health_bar.value = health
	$AnimatedSprite2D.modulate = Color(1, 0, 0) # Pisca vermelho!
	await get_tree().create_timer(0.2).timeout
	$AnimatedSprite2D.modulate = Color(1, 1, 1) # Volta ao normal
	
	if health <= 0: queue_free() # Boss Morre

# Se o Player encostar no corpo do Boss
func _on_hitbox_player_body_entered(body):
	if body.name == "Player": body.take_damage()

func _on_head_box_body_entered(body):
	if body.name == "Player":
		# 1. Faz o Player quicar no ar (impulso para cima!)
		body.velocity.y = -400.0 
		
		# 2. Verifica se é um Boss (que tem função take_damage) ou Inimigo Comum
		if has_method("take_damage"):
			take_damage(1) # Se for Boss, tira 1 de vida
		else:
			queue_free() # Se for inimigo comum, morre/explode na hora!
